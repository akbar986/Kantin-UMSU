"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { QrCode, ChevronLeft } from "lucide-react"
import Link from "next/link"

export default function ScanPage() {
  const router = useRouter()
  const [tableNumber, setTableNumber] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (tableNumber.trim()) {
      localStorage.setItem("orderSource", "qr")
      localStorage.setItem("tableFromQR", tableNumber)
      router.push(`/menu?table=${tableNumber}`)
    }
  }

  const handleDemoScan = (table: string) => {
    localStorage.setItem("orderSource", "qr")
    localStorage.setItem("tableFromQR", table)
    router.push(`/menu?table=${table}`)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-gradient-to-r from-purple-600 via-purple-500 to-blue-600 text-white shadow-lg animate-fade-in-up">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-3">
            <Link href="/">
              <Button variant="ghost" size="icon" className="text-white hover:bg-white/20">
                <ChevronLeft className="w-5 h-5" />
              </Button>
            </Link>
            <h1 className="text-xl font-bold">Scan QR Code Meja</h1>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8 max-w-md">
        <div className="space-y-6">
          {/* QR Scanner Placeholder */}
          <Card className="p-8 shadow-md animate-slide-in-right border-purple-200">
            <div className="flex flex-col items-center text-center space-y-4">
              <div className="w-48 h-48 border-4 border-dashed border-purple-400 rounded-lg flex items-center justify-center bg-gradient-to-br from-purple-50 to-blue-50 hover:bg-purple-100 transition-colors">
                <QrCode className="w-24 h-24 text-purple-600 animate-pulse-slow" />
              </div>
              <div>
                <h2 className="font-bold text-lg mb-2">Scan QR Code Meja</h2>
                <p className="text-sm text-muted-foreground">
                  Arahkan kamera ke QR code yang ada di meja Anda untuk mulai memesan
                </p>
              </div>
            </div>
          </Card>

          {/* Manual Table Number Input */}
          <Card className="p-6 shadow-md animate-slide-in-right border-purple-200" style={{ animationDelay: "0.1s" }}>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="table">Atau masukkan nomor meja manual</Label>
                <Input
                  id="table"
                  type="text"
                  placeholder="Contoh: A1, B2, C3"
                  value={tableNumber}
                  onChange={(e) => setTableNumber(e.target.value)}
                  className="mt-2 border-purple-200 focus:border-purple-500 transition-colors"
                />
              </div>
              <Button
                type="submit"
                className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:shadow-lg"
                disabled={!tableNumber.trim()}
              >
                Lanjutkan
              </Button>
            </form>
          </Card>

          {/* Demo Tables */}
          <Card className="p-6 shadow-md animate-slide-in-right border-purple-200" style={{ animationDelay: "0.2s" }}>
            <h3 className="font-semibold mb-3">Demo - Pilih Meja</h3>
            <div className="grid grid-cols-3 gap-3">
              {["A1", "A2", "A3", "B1", "B2", "B3", "C1", "C2", "C3"].map((table, index) => (
                <Button
                  key={table}
                  variant="outline"
                  onClick={() => handleDemoScan(table)}
                  className="hover:shadow-md transition-all hover:scale-105 hover:border-purple-500 hover:bg-purple-50"
                  style={{ animationDelay: `${index * 0.05}s` }}
                >
                  Meja {table}
                </Button>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </div>
  )
}

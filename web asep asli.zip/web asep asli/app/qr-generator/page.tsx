"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Download, ChevronLeft } from "lucide-react"
import Link from "next/link"
import QRCode from "qrcode"

export default function QRGeneratorPage() {
  const [tableNumber, setTableNumber] = useState("A1")
  const [qrSize, setQrSize] = useState(300)
  const [qrCodeUrl, setQrCodeUrl] = useState("")

  const menuUrl = typeof window !== "undefined" ? `${window.location.origin}/menu?table=${tableNumber}` : ""

  const downloadQR = () => {
    const canvas = document.getElementById("qr-canvas") as HTMLCanvasElement
    if (canvas) {
      const url = canvas.toDataURL("image/png")
      const link = document.createElement("a")
      link.download = `qr-table-${tableNumber}.png`
      link.href = url
      link.click()
    }
  }

  React.useEffect(() => {
    if (typeof window !== "undefined") {
      QRCode.toDataURL(menuUrl, { width: qrSize })
        .then(setQrCodeUrl)
        .catch((err) => console.error(err))
    }
  }, [tableNumber, qrSize])

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-primary text-primary-foreground shadow-md">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-3">
            <Link href="/vendor/dashboard">
              <Button variant="ghost" size="icon" className="text-primary-foreground hover:bg-primary-foreground/20">
                <ChevronLeft className="w-5 h-5" />
              </Button>
            </Link>
            <h1 className="text-xl font-bold">Generator QR Code Meja</h1>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8 max-w-2xl">
        <div className="grid md:grid-cols-2 gap-6">
          {/* Configuration */}
          <Card className="p-6">
            <h2 className="font-bold mb-4">Konfigurasi QR Code</h2>
            <div className="space-y-4">
              <div>
                <Label htmlFor="table">Nomor Meja</Label>
                <Input
                  id="table"
                  value={tableNumber}
                  onChange={(e) => setTableNumber(e.target.value)}
                  placeholder="A1"
                  className="mt-2"
                />
              </div>

              <div>
                <Label htmlFor="size">Ukuran (px)</Label>
                <Input
                  id="size"
                  type="number"
                  value={qrSize}
                  onChange={(e) => setQrSize(Number(e.target.value))}
                  min={200}
                  max={500}
                  className="mt-2"
                />
              </div>

              <div className="pt-2">
                <Label className="text-sm text-muted-foreground">URL Target</Label>
                <p className="text-sm mt-1 break-all bg-muted p-2 rounded">{menuUrl}</p>
              </div>

              <Button className="w-full" onClick={downloadQR}>
                <Download className="w-4 h-4 mr-2" />
                Download QR Code
              </Button>
            </div>
          </Card>

          {/* QR Preview */}
          <Card className="p-6">
            <h2 className="font-bold mb-4">Preview</h2>
            <div className="flex flex-col items-center">
              <div className="bg-white p-6 rounded-lg shadow-inner">
                {qrCodeUrl && (
                  <img
                    id="qr-canvas"
                    src={qrCodeUrl || "/placeholder.svg"}
                    width={qrSize}
                    height={qrSize}
                    className="max-w-full h-auto"
                  />
                )}
              </div>
              <div className="mt-4 text-center">
                <p className="font-bold text-lg">Meja {tableNumber}</p>
                <p className="text-sm text-muted-foreground">Scan untuk pesan</p>
              </div>
            </div>
          </Card>
        </div>

        {/* Bulk Generator */}
        <Card className="p-6 mt-6">
          <h2 className="font-bold mb-4">Generator Multiple Meja</h2>
          <p className="text-sm text-muted-foreground mb-4">Generate QR code untuk beberapa meja sekaligus</p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {["A1", "A2", "A3", "A4", "B1", "B2", "B3", "B4", "C1", "C2", "C3", "C4"].map((table) => (
              <Button key={table} variant="outline" size="sm" onClick={() => setTableNumber(table)}>
                Meja {table}
              </Button>
            ))}
          </div>
        </Card>
      </div>
    </div>
  )
}

// Add React import
import * as React from "react"

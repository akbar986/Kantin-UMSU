"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Input } from "@/components/ui/input"
import { ChevronLeft, QrCode, Smartphone, CreditCard, Wallet, Truck, UtensilsCrossed } from "lucide-react"
import { saveOrder, generateOrderId } from "@/lib/order-store"
import type { CartItem, Order } from "@/lib/types"
import Link from "next/link"

export default function CheckoutPage() {
  const router = useRouter()
  const [cart, setCart] = useState<CartItem[]>([])
  const [tableNumber, setTableNumber] = useState("")
  const [paymentMethod, setPaymentMethod] = useState<"gopay" | "shopee" | "qris" | "cash">("gopay")
  const [phoneNumber, setPhoneNumber] = useState("")
  const [showPhoneInput, setShowPhoneInput] = useState(false)
  const [isFromQR, setIsFromQR] = useState(false)
  const [deliveryType, setDeliveryType] = useState<"dine-in" | "takeaway">("dine-in")

  useEffect(() => {
    const savedCart = localStorage.getItem("currentCart")
    const savedTable = localStorage.getItem("currentTable")
    const savedSource = localStorage.getItem("orderSource")

    if (savedCart) {
      setCart(JSON.parse(savedCart))
    }
    if (savedTable) {
      setTableNumber(savedTable)
    }
    if (savedSource === "qr") {
      setIsFromQR(true)
    }
  }, [])

  useEffect(() => {
    setShowPhoneInput(["gopay", "shopee"].includes(paymentMethod))
  }, [paymentMethod])

  const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0)
  const tax = 0
  const total = subtotal + tax

  const handlePlaceOrder = () => {
    if (deliveryType === "dine-in" && !tableNumber) {
      alert("Masukkan nomor meja")
      return
    }

    if (showPhoneInput && !phoneNumber) {
      alert("Masukkan nomor HP untuk konfirmasi pembayaran")
      return
    }

    completeOrder()
  }

  const completeOrder = () => {
    const order: Order = {
      id: generateOrderId(),
      tableNumber: deliveryType === "takeaway" ? "Takeaway" : tableNumber,
      items: cart,
      total,
      status: "pending",
      paymentMethod,
      phoneNumber: showPhoneInput ? phoneNumber : undefined,
      paymentConfirmed: paymentMethod !== "cash",
      createdAt: new Date(),
      updatedAt: new Date(),
      source: isFromQR ? "qr" : "menu",
      isDelivery: deliveryType === "takeaway",
    }

    saveOrder(order)
    localStorage.removeItem("currentCart")
    localStorage.removeItem("currentTable")
    localStorage.removeItem("orderSource")

    router.push(`/order-status/${order.id}`)
  }

  if (cart.length === 0) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-4 bg-gradient-to-br from-primary/10 via-background to-secondary/10">
        <Card className="p-8 text-center shadow-lg border-primary/20">
          <p className="text-muted-foreground mb-4">Keranjang kosong</p>
          <Link href="/menu?table=demo">
            <Button className="bg-gradient-to-r from-primary to-secondary">Kembali ke Menu</Button>
          </Link>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50">
      <div className="sticky top-0 z-10 bg-gradient-to-r from-purple-600 via-purple-500 to-purple-700 text-white shadow-lg animate-fade-in-up">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" className="text-white hover:bg-white/20" onClick={() => router.back()}>
              <ChevronLeft className="w-5 h-5" />
            </Button>
            <h1 className="text-xl font-bold">Konfirmasi Pesanan</h1>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-6 max-w-2xl space-y-6">
        <Card className="p-4 border-2 border-purple-200 shadow-lg bg-gradient-to-br from-purple-50 to-blue-50 animate-slide-in-right">
          <Label className="text-sm font-semibold mb-3 block">Tipe Pengambilan</Label>
          <RadioGroup value={deliveryType} onValueChange={(value: any) => setDeliveryType(value)}>
            <div className="space-y-2">
              <div
                className={`p-3 border-2 rounded-xl cursor-pointer transition-all ${
                  deliveryType === "dine-in"
                    ? "border-purple-500 bg-gradient-to-r from-purple-100 to-purple-50 shadow-sm"
                    : "border-purple-200 hover:border-purple-400 hover:bg-purple-50"
                }`}
              >
                <div className="flex items-center gap-3">
                  <RadioGroupItem value="dine-in" id="dine-in" />
                  <UtensilsCrossed className="w-5 h-5 text-purple-600" />
                  <Label htmlFor="dine-in" className="cursor-pointer font-semibold">
                    Makan di Tempat
                  </Label>
                </div>
              </div>

              <div
                className={`p-3 border-2 rounded-xl cursor-pointer transition-all ${
                  deliveryType === "takeaway"
                    ? "border-purple-500 bg-gradient-to-r from-purple-100 to-purple-50 shadow-sm"
                    : "border-purple-200 hover:border-purple-400 hover:bg-purple-50"
                }`}
              >
                <div className="flex items-center gap-3">
                  <RadioGroupItem value="takeaway" id="takeaway" />
                  <Truck className="w-5 h-5 text-purple-600" />
                  <Label htmlFor="takeaway" className="cursor-pointer font-semibold">
                    Takeaway
                  </Label>
                </div>
              </div>
            </div>
          </RadioGroup>
        </Card>

        {deliveryType === "dine-in" && !isFromQR && (
          <Card className="p-4 border-l-4 border-l-purple-600 shadow-lg bg-gradient-to-r from-purple-50 to-transparent animate-slide-in-right">
            <Label className="text-sm text-muted-foreground font-semibold">Pilih Nomor Meja</Label>
            <div className="mt-4 grid grid-cols-5 gap-2">
              {["A1", "A2", "A3", "B1", "B2", "B3", "C1", "C2", "C3"].map((table) => (
                <button
                  key={table}
                  onClick={() => setTableNumber(table)}
                  className={`p-2 rounded-lg font-semibold transition-all text-sm ${
                    tableNumber === table
                      ? "bg-gradient-to-r from-purple-600 to-blue-600 text-white shadow-md"
                      : "bg-white border border-purple-200 hover:border-purple-400 hover:shadow-sm"
                  }`}
                >
                  {table}
                </button>
              ))}
            </div>
          </Card>
        )}

        {deliveryType === "dine-in" && isFromQR && (
          <Card className="p-4 border-l-4 border-l-purple-600 shadow-lg bg-gradient-to-r from-purple-50 to-transparent animate-slide-in-right">
            <Label className="text-sm text-muted-foreground font-semibold">Nomor Meja</Label>
            <p className="text-3xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent mt-2">
              Meja {tableNumber}
            </p>
            <p className="text-xs text-muted-foreground mt-2 bg-green-50 border border-green-200 p-2 rounded-lg">
              ✓ Meja terdeteksi otomatis dari QR code
            </p>
          </Card>
        )}

        <Card className="p-6 shadow-lg border-primary/20 animate-slide-in-right" style={{ animationDelay: "0.1s" }}>
          <h2 className="font-bold mb-4 text-lg flex items-center gap-2">
            <span className="w-1 h-6 bg-gradient-to-b from-primary to-secondary rounded-full"></span>
            Pesanan Anda
          </h2>
          <div className="space-y-4">
            {cart.map((item) => (
              <div
                key={item.id}
                className="flex gap-4 pb-4 border-b last:border-b-0 hover:bg-primary/5 p-2 rounded-lg transition-colors"
              >
                <div className="relative w-20 h-20 rounded-lg overflow-hidden flex-shrink-0 shadow-md border border-primary/10">
                  <Image src={item.image || "/placeholder.svg"} alt={item.name} fill className="object-cover" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-base">{item.name}</h3>
                  <p className="text-sm text-muted-foreground mt-1">
                    {item.quantity} x Rp {item.price.toLocaleString("id-ID")}
                  </p>
                </div>
                <div className="text-right">
                  <p className="font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
                    Rp {(item.price * item.quantity).toLocaleString("id-ID")}
                  </p>
                </div>
              </div>
            ))}
          </div>

          <div className="border-t border-primary/10 mt-6 pt-4 space-y-3">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Subtotal</span>
              <span className="font-medium">Rp {subtotal.toLocaleString("id-ID")}</span>
            </div>
            <div className="flex justify-between font-bold text-lg bg-gradient-to-r from-primary/15 to-secondary/15 p-3 rounded-lg border border-primary/20">
              <span>Total Bayar</span>
              <span className="text-primary">Rp {total.toLocaleString("id-ID")}</span>
            </div>
          </div>
        </Card>

        <Card className="p-6 shadow-lg border-primary/20 animate-slide-in-right" style={{ animationDelay: "0.2s" }}>
          <h2 className="font-bold mb-4 text-lg flex items-center gap-2">
            <CreditCard className="w-5 h-5 text-primary" />
            Metode Pembayaran
          </h2>
          <RadioGroup value={paymentMethod} onValueChange={(value: any) => setPaymentMethod(value)}>
            <div className="space-y-3">
              <div
                className={`p-4 border-2 rounded-xl cursor-pointer transition-all ${
                  paymentMethod === "gopay"
                    ? "border-primary bg-gradient-to-r from-primary/20 to-primary/10 shadow-md"
                    : "border-primary/20 hover:border-primary/50"
                }`}
              >
                <div className="flex items-center gap-3">
                  <RadioGroupItem value="gopay" id="gopay" />
                  <Wallet className="w-5 h-5 text-green-500" />
                  <div className="flex-1">
                    <Label htmlFor="gopay" className="cursor-pointer font-semibold">
                      GoPay
                    </Label>
                    <p className="text-xs text-muted-foreground">Bayar dengan dompet digital GoPay</p>
                  </div>
                </div>
              </div>

              <div
                className={`p-4 border-2 rounded-xl cursor-pointer transition-all ${
                  paymentMethod === "shopee"
                    ? "border-primary bg-gradient-to-r from-primary/20 to-primary/10 shadow-md"
                    : "border-primary/20 hover:border-primary/50"
                }`}
              >
                <div className="flex items-center gap-3">
                  <RadioGroupItem value="shopee" id="shopee" />
                  <Wallet className="w-5 h-5 text-orange-500" />
                  <div className="flex-1">
                    <Label htmlFor="shopee" className="cursor-pointer font-semibold">
                      ShopeePay
                    </Label>
                    <p className="text-xs text-muted-foreground">Bayar dengan dompet digital ShopeePay</p>
                  </div>
                </div>
              </div>

              <div
                className={`p-4 border-2 rounded-xl cursor-pointer transition-all ${
                  paymentMethod === "qris"
                    ? "border-primary bg-gradient-to-r from-primary/20 to-primary/10 shadow-md"
                    : "border-primary/20 hover:border-primary/50"
                }`}
              >
                <div className="flex items-center gap-3">
                  <RadioGroupItem value="qris" id="qris" />
                  <QrCode className="w-5 h-5 text-blue-600" />
                  <div className="flex-1">
                    <Label htmlFor="qris" className="cursor-pointer font-semibold">
                      QRIS
                    </Label>
                    <p className="text-xs text-muted-foreground">Scan kode QRIS untuk pembayaran instant</p>
                  </div>
                </div>
              </div>

              <div
                className={`p-4 border-2 rounded-xl cursor-pointer transition-all ${
                  paymentMethod === "cash"
                    ? "border-primary bg-gradient-to-r from-primary/20 to-primary/10 shadow-md"
                    : "border-primary/20 hover:border-primary/50"
                }`}
              >
                <div className="flex items-center gap-3">
                  <RadioGroupItem value="cash" id="cash" />
                  <CreditCard className="w-5 h-5 text-yellow-600" />
                  <div className="flex-1">
                    <Label htmlFor="cash" className="cursor-pointer font-semibold">
                      Tunai
                    </Label>
                    <p className="text-xs text-muted-foreground">Bayar di kasir - Akan dikonfirmasi admin</p>
                  </div>
                </div>
              </div>
            </div>
          </RadioGroup>

          {showPhoneInput && (
            <div className="mt-4 pt-4 border-t border-primary/10 animate-fade-in-up">
              <Label className="text-sm font-semibold flex items-center gap-2 mb-2">
                <Smartphone className="w-4 h-4 text-primary" />
                Nomor HP untuk Konfirmasi
              </Label>
              <Input
                type="tel"
                placeholder="Contoh: 081234567890"
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
                className="border-primary/30 focus:border-primary"
              />
              <p className="text-xs text-muted-foreground mt-2">
                Masukkan nomor HP yang terdaftar di {paymentMethod === "gopay" ? "GoPay" : "ShopeePay"}
              </p>
            </div>
          )}
        </Card>

        <Button
          size="lg"
          className="w-full bg-gradient-to-r from-primary to-secondary hover:shadow-lg text-base font-semibold py-6 animate-fade-in-up"
          onClick={handlePlaceOrder}
        >
          Konfirmasi & Lanjutkan Pembayaran
        </Button>

        <p className="text-xs text-center text-muted-foreground">
          Dengan menekan tombol di atas, Anda menyetujui ketentuan dan kondisi kami
        </p>
      </div>
    </div>
  )
}

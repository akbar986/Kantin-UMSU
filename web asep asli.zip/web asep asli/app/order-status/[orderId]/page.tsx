"use client"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { CheckCircle2, Clock, ChefHat, Bell, Loader2, Home } from "lucide-react"
import { getOrderById } from "@/lib/order-store"
import type { Order } from "@/lib/types"
import Link from "next/link"

export default function OrderStatusPage() {
  const params = useParams()
  const router = useRouter()
  const orderId = params.orderId as string
  const [order, setOrder] = useState<Order | null>(null)

  useEffect(() => {
    const fetchOrder = () => {
      const foundOrder = getOrderById(orderId)
      setOrder(foundOrder)
    }

    fetchOrder()

    const interval = setInterval(fetchOrder, 3000)
    return () => clearInterval(interval)
  }, [orderId])

  if (!order) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-50 via-white to-blue-50">
        <p className="animate-pulse text-lg font-semibold">Memuat pesanan...</p>
      </div>
    )
  }

  const statusSteps = [
    { key: "pending", label: "Pesanan Dikonfirmasi", icon: Clock, description: "Pesanan Anda telah diterima" },
    { key: "confirmed", label: "Sedang Dibuat", icon: ChefHat, description: "Chef sedang menyiapkan pesanan Anda" },
    { key: "preparing", label: "Siap Diambil", icon: Bell, description: "Pesanan Anda siap dinikmati" },
    { key: "ready", label: "Selesai", icon: CheckCircle2, description: "Pesanan telah selesai" },
  ]

  const currentStepIndex = statusSteps.findIndex((step) => step.key === order.status)

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50 pb-8">
      <div className="container mx-auto px-4 py-8 max-w-2xl">
        <div className="text-center mb-8 animate-fade-in-up">
          <div className="flex items-center justify-center w-20 h-20 bg-gradient-to-br from-purple-200 to-blue-200 rounded-full mx-auto mb-4 animate-pulse-slow border-2 border-purple-400">
            <CheckCircle2 className="w-10 h-10 text-purple-600" />
          </div>
          <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
            Pesanan Diterima!
          </h1>
          <p className="text-muted-foreground mt-2">
            Order ID: <span className="font-mono font-semibold text-purple-600">{order.id}</span>
          </p>
        </div>

        <Card className="p-6 mb-6 border-l-4 border-l-purple-600 shadow-lg bg-gradient-to-r from-purple-50 to-transparent">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-sm text-muted-foreground font-semibold">Lokasi</p>
              <p className="text-lg font-bold text-purple-600 mt-1">{order.tableNumber}</p>
            </div>
            <div className="text-right">
              <p className="text-sm text-muted-foreground font-semibold">Total Bayar</p>
              <p className="text-lg font-bold text-purple-600 mt-1">Rp {order.total.toLocaleString("id-ID")}</p>
            </div>
          </div>
        </Card>

        <Card
          className="p-6 mb-6 shadow-lg border-purple-200 animate-slide-in-right"
          style={{ animationDelay: "0.1s" }}
        >
          <h2 className="font-bold mb-6 text-lg flex items-center gap-2">
            <Clock className="w-5 h-5 text-purple-600" />
            Status Pesanan
          </h2>
          <div className="space-y-6">
            {statusSteps.map((step, index) => {
              const Icon = step.icon
              const isCompleted = index <= currentStepIndex
              const isCurrent = index === currentStepIndex

              return (
                <div
                  key={step.key}
                  className={`flex items-start gap-4 animate-fade-in-up`}
                  style={{ animationDelay: `${index * 0.1}s` }}
                >
                  <div
                    className={`flex items-center justify-center w-12 h-12 rounded-full flex-shrink-0 transition-all ${
                      isCompleted
                        ? "bg-gradient-to-br from-purple-600 to-blue-600 text-white shadow-lg"
                        : "bg-muted/50 text-muted-foreground border-2 border-muted"
                    } ${isCurrent ? "ring-4 ring-purple-300 ring-offset-2" : ""}`}
                  >
                    {isCurrent && !isCompleted ? (
                      <Loader2 className="w-6 h-6 animate-spin" />
                    ) : (
                      <Icon className="w-6 h-6" />
                    )}
                  </div>
                  <div className="flex-1 pt-2">
                    <p className={`font-semibold text-base ${isCurrent ? "text-purple-600" : ""}`}>{step.label}</p>
                    <p className="text-sm text-muted-foreground mt-1">{step.description}</p>
                    {isCurrent && (
                      <div className="mt-2 inline-block">
                        <div className="text-xs bg-gradient-to-r from-purple-200 to-purple-100 text-purple-700 px-3 py-1 rounded-full font-semibold animate-pulse border border-purple-300">
                          Sedang berlangsung
                        </div>
                      </div>
                    )}
                  </div>
                  {isCompleted && <CheckCircle2 className="w-5 h-5 text-purple-600 mt-2 flex-shrink-0" />}
                </div>
              )
            })}
          </div>
        </Card>

        <Card
          className="p-6 mb-6 shadow-lg border-purple-200 animate-slide-in-right"
          style={{ animationDelay: "0.2s" }}
        >
          <h2 className="font-bold mb-4 text-lg">Detail Pesanan</h2>
          <div className="space-y-3">
            <div className="flex justify-between pb-3 border-b border-purple-200">
              <span className="text-muted-foreground">Nomor Meja / Tipe</span>
              <span className="font-semibold">{order.tableNumber}</span>
            </div>
            <div className="flex justify-between pb-3 border-b border-purple-200">
              <span className="text-muted-foreground">Metode Pembayaran</span>
              <span className="font-semibold capitalize">{order.paymentMethod}</span>
            </div>
            <div className="flex justify-between pb-3 border-b border-purple-200">
              <span className="text-muted-foreground">Jumlah Item</span>
              <span className="font-semibold">{order.items.reduce((sum, item) => sum + item.quantity, 0)} item</span>
            </div>
            <div className="flex justify-between bg-gradient-to-r from-purple-100 to-blue-100 p-3 rounded-lg border border-purple-200">
              <span className="font-semibold">Total</span>
              <span className="font-bold text-purple-600 text-lg">Rp {order.total.toLocaleString("id-ID")}</span>
            </div>
          </div>
        </Card>

        <Card
          className="p-6 mb-6 shadow-lg border-purple-200 animate-slide-in-right"
          style={{ animationDelay: "0.3s" }}
        >
          <h2 className="font-bold mb-4">Item yang Dipesan</h2>
          <div className="space-y-3">
            {order.items.map((item) => (
              <div
                key={item.id}
                className="flex justify-between items-center pb-3 border-b border-purple-200 last:border-b-0"
              >
                <div>
                  <p className="font-semibold">{item.name}</p>
                  <p className="text-sm text-muted-foreground">
                    {item.quantity}x @ Rp {item.price.toLocaleString("id-ID")}
                  </p>
                </div>
                <p className="font-bold text-purple-600">Rp {(item.price * item.quantity).toLocaleString("id-ID")}</p>
              </div>
            ))}
          </div>
        </Card>

        <div className="space-y-3 animate-fade-in-up" style={{ animationDelay: "0.4s" }}>
          <Link href="/menu?table=demo" className="block">
            <Button
              size="lg"
              className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:shadow-lg font-semibold"
            >
              <Home className="w-4 h-4 mr-2" />
              Kembali ke Menu
            </Button>
          </Link>
          <Button
            size="lg"
            variant="outline"
            className="w-full border-purple-200 hover:bg-purple-50 bg-transparent"
            onClick={() => {
              window.location.reload()
            }}
          >
            <Clock className="w-4 h-4 mr-2" />
            Refresh Status Pesanan
          </Button>
        </div>
      </div>
    </div>
  )
}

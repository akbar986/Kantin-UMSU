import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { ShoppingBag, QrCode, Utensils, ArrowRight } from "lucide-react"

export default function HomePage() {
  return (
    <main className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-purple-600 via-purple-500 to-blue-600 text-white animate-fade-in-up">
        <div className="container mx-auto px-4 py-8">
          <div className="flex items-center gap-3 mb-2">
            <div className="flex items-center justify-center w-12 h-12 bg-white/20 rounded-xl hover:scale-110 transition-transform">
              <Utensils className="w-6 h-6" />
            </div>
            <h1 className="text-2xl font-bold">Kantin Kampus UMSU</h1>
          </div>
          <p className="text-white/90">Pesan makanan & minuman dengan cepat dan mudah</p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12">
        <div className="grid md:grid-cols-2 gap-8 mb-12">
          {/* Main CTA Cards */}
          <Link href="/scan">
            <Card className="p-8 hover:shadow-xl transition-all cursor-pointer border-0 h-full bg-gradient-to-br from-white to-purple-50 hover:from-purple-50 hover:to-blue-50 hover:scale-105 animate-fade-in-up group border-purple-200">
              <div className="flex flex-col items-center text-center gap-6 h-full justify-between">
                <div className="flex items-center justify-center w-20 h-20 bg-gradient-to-br from-purple-100 to-purple-200 rounded-2xl group-hover:bg-gradient-to-br group-hover:from-purple-200 group-hover:to-blue-200 group-hover:shadow-lg transition-all group-hover:scale-110">
                  <QrCode className="w-10 h-10 text-purple-600" />
                </div>
                <div>
                  <h3 className="font-bold text-xl mb-2">Scan QR Code</h3>
                  <p className="text-muted-foreground mb-4">Scan kode QR yang ada di meja makan Anda</p>
                  <div className="flex items-center justify-center gap-2 text-purple-600 font-semibold text-sm group-hover:gap-3 transition-all">
                    Mulai Pesan <ArrowRight className="w-4 h-4" />
                  </div>
                </div>
              </div>
            </Card>
          </Link>

          <Link href="/menu?table=demo">
            <Card
              className="p-8 hover:shadow-xl transition-all cursor-pointer border-0 h-full bg-gradient-to-br from-white to-blue-50 hover:from-blue-50 hover:to-purple-50 hover:scale-105 animate-fade-in-up group border-purple-200"
              style={{ animationDelay: "0.1s" }}
            >
              <div className="flex flex-col items-center text-center gap-6 h-full justify-between">
                <div className="flex items-center justify-center w-20 h-20 bg-gradient-to-br from-blue-100 to-blue-200 rounded-2xl group-hover:bg-gradient-to-br group-hover:from-blue-200 group-hover:to-purple-200 group-hover:shadow-lg transition-all group-hover:scale-110">
                  <ShoppingBag className="w-10 h-10 text-blue-600" />
                </div>
                <div>
                  <h3 className="font-bold text-xl mb-2">Lihat Menu</h3>
                  <p className="text-muted-foreground mb-4">Langsung ke menu tanpa scan QR</p>
                  <div className="flex items-center justify-center gap-2 text-blue-600 font-semibold text-sm group-hover:gap-3 transition-all">
                    Jelajahi Menu <ArrowRight className="w-4 h-4" />
                  </div>
                </div>
              </div>
            </Card>
          </Link>
        </div>

        {/* Features */}
        <div className="mb-12">
          <h2 className="text-3xl font-bold text-center mb-8 animate-fade-in-up">Fitur Unggulan</h2>
          <div className="grid md:grid-cols-3 gap-6">
            <Card
              className="p-6 border-l-4 border-l-purple-600 shadow-md hover:shadow-lg transition-all hover:scale-105 animate-fade-in-up border-purple-200"
              style={{ animationDelay: "0.1s" }}
            >
              <div className="w-10 h-10 bg-gradient-to-br from-purple-100 to-purple-200 rounded-lg flex items-center justify-center mb-4 group-hover:bg-gradient-to-br group-hover:from-purple-200 group-hover:to-blue-200">
                <QrCode className="w-6 h-6 text-purple-600" />
              </div>
              <h3 className="font-semibold mb-2">Pemesanan Cepat</h3>
              <p className="text-sm text-muted-foreground">
                Scan QR code dan langsung pesan tanpa perlu berpindah tempat
              </p>
            </Card>

            <Card
              className="p-6 border-l-4 border-l-blue-600 shadow-md hover:shadow-lg transition-all hover:scale-105 animate-fade-in-up border-purple-200"
              style={{ animationDelay: "0.2s" }}
            >
              <div className="w-10 h-10 bg-gradient-to-br from-blue-100 to-blue-200 rounded-lg flex items-center justify-center mb-4">
                <ShoppingBag className="w-6 h-6 text-blue-600" />
              </div>
              <h3 className="font-semibold mb-2">Berbagai Pilihan</h3>
              <p className="text-sm text-muted-foreground">Menu lengkap makanan dan minuman dengan harga terjangkau</p>
            </Card>

            <Card
              className="p-6 border-l-4 border-l-purple-600 shadow-md hover:shadow-lg transition-all hover:scale-105 animate-fade-in-up border-purple-200"
              style={{ animationDelay: "0.3s" }}
            >
              <div className="w-10 h-10 bg-gradient-to-br from-purple-100 to-purple-200 rounded-lg flex items-center justify-center mb-4">
                <Utensils className="w-6 h-6 text-purple-600" />
              </div>
              <h3 className="font-semibold mb-2">Tracking Real-time</h3>
              <p className="text-sm text-muted-foreground">
                Pantau status pesanan Anda secara real-time hingga siap dinikmati
              </p>
            </Card>
          </div>
        </div>

        {/* Vendor Login */}
        <div className="text-center animate-fade-in-up" style={{ animationDelay: "0.4s" }}>
          <Card className="p-6 bg-gradient-to-r from-purple-100 to-blue-100 border-purple-200 shadow-md hover:shadow-lg transition-all hover:scale-105">
            <p className="text-muted-foreground mb-4">Apakah Anda penjual kantin?</p>
            <Link href="/vendor/login">
              <Button className="bg-gradient-to-r from-purple-600 to-blue-600 hover:shadow-lg">
                Login Penjual
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </Link>
          </Card>
        </div>
      </div>
    </main>
  )
}

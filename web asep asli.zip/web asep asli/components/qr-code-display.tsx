"use client"

import { Card } from "@/components/ui/card"
import { QrCode } from "lucide-react"

interface QRCodeDisplayProps {
  tableNumber: string
  size?: number
}

export function QRCodeDisplay({ tableNumber, size = 200 }: QRCodeDisplayProps) {
  const menuUrl = typeof window !== "undefined" ? `${window.location.origin}/menu?table=${tableNumber}` : ""

  return (
    <Card className="p-6 inline-block">
      <div className="flex flex-col items-center space-y-3">
        <div className="bg-white p-4 rounded-lg border-4 border-black" style={{ width: size, height: size }}>
          <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-primary/10 to-primary/5">
            <QrCode className="w-1/2 h-1/2 text-primary" />
          </div>
        </div>
        <div className="text-center">
          <p className="font-bold text-xl">Meja {tableNumber}</p>
          <p className="text-sm text-muted-foreground">Scan untuk pesan</p>
        </div>
        <div className="text-xs text-muted-foreground max-w-full break-all">{menuUrl}</div>
      </div>
    </Card>
  )
}

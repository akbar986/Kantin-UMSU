// ===================== STATE MANAGEMENT =====================
const appState = {
  currentPage: "home-page",
  selectedTable: null,
  cart: [],
  orders: [],
  menuItems: [],
  users: [],
  currentUser: null,
  deliveryType: "dine-in",
  selectedPayment: null,
  tableFromQR: false,
}

// ===================== INITIALIZATION =====================
document.addEventListener("DOMContentLoaded", () => {
  initializeData()
  goToPage("home-page")
  attachEventListeners()
})

function initializeData() {
  // Load from localStorage or use default data
  const stored = localStorage.getItem("appData")
  if (stored) {
    const data = JSON.parse(stored)
    appState.orders = data.orders || []
    appState.menuItems = data.menuItems || []
    appState.users = data.users || []
  } else {
    // Default menu items
    appState.menuItems = [
      { id: 1, name: "Nasi Goreng", price: 15000, category: "makanan", image: "/nasi-goreng.jpg" },
      { id: 2, name: "Mie Goreng", price: 14000, category: "makanan", image: "/mie-goreng.jpg" },
      { id: 3, name: "Ayam Goreng", price: 18000, category: "makanan", image: "/ayam-goreng.jpg" },
      { id: 4, name: "Soto Ayam", price: 12000, category: "makanan", image: "/soto-ayam.jpg" },
      { id: 5, name: "Es Teh", price: 5000, category: "minuman", image: "/es-teh.jpg" },
      { id: 6, name: "Kopi", price: 7000, category: "minuman", image: "/kopi.jpg" },
    ]

    // Default admin user
    appState.users = [{ id: 1, email: "admin@kantin.com", password: "admin123" }]

    saveData()
  }
}

function saveData() {
  localStorage.setItem(
    "appData",
    JSON.stringify({
      orders: appState.orders,
      menuItems: appState.menuItems,
      users: appState.users,
    }),
  )
}

// ===================== PAGE NAVIGATION =====================
function goToPage(pageName) {
  // Hide all pages
  document.querySelectorAll(".page").forEach((page) => {
    page.classList.remove("active")
  })

  // Show target page
  const targetPage = document.getElementById(pageName)
  if (targetPage) {
    targetPage.classList.add("active")
    appState.currentPage = pageName

    // Load page specific content
    if (pageName === "menu-page") {
      renderMenu("all")
      appState.tableFromQR = false
    } else if (pageName === "checkout-page") {
      renderCheckout()
    } else if (pageName === "track-page") {
      renderTracking()
    } else if (pageName === "order-status-page") {
      renderOrderStatus()
    } else if (pageName === "vendor-dashboard-page") {
      renderVendorDashboard()
    }
  }
}

// ===================== MENU PAGE =====================
function renderMenu(filter = "all") {
  const menuList = document.getElementById("menu-list")
  menuList.innerHTML = ""

  const filteredItems =
    filter === "all" ? appState.menuItems : appState.menuItems.filter((item) => item.category === filter)

  filteredItems.forEach((item) => {
    const cartItem = appState.cart.find((c) => c.id === item.id)
    const qty = cartItem ? cartItem.quantity : 0

    const html = `
      <div class="menu-item">
        <img src="${item.image}" alt="${item.name}" class="menu-item-image">
        <div class="menu-item-content">
          <div class="menu-item-name">${item.name}</div>
          <div class="menu-item-price">Rp ${item.price.toLocaleString()}</div>
          <div class="menu-item-actions">
            <button class="qty-btn" onclick="decreaseQty(${item.id})">-</button>
            <div class="qty-display">${qty}</div>
            <button class="qty-btn" onclick="increaseQty(${item.id})">+</button>
          </div>
        </div>
      </div>
    `
    menuList.innerHTML += html
  })
}

function filterMenu(category) {
  document.querySelectorAll(".filter-btn").forEach((btn) => {
    btn.classList.remove("active")
  })
  event.target.classList.add("active")
  renderMenu(category)
}

function increaseQty(itemId) {
  const item = appState.menuItems.find((m) => m.id === itemId)
  let cartItem = appState.cart.find((c) => c.id === itemId)

  if (!cartItem) {
    cartItem = { ...item, quantity: 1 }
    appState.cart.push(cartItem)
  } else {
    cartItem.quantity++
  }

  renderMenu(appState.menuItems.find((m) => m.id === itemId)?.category || "all")
}

function decreaseQty(itemId) {
  const cartItem = appState.cart.find((c) => c.id === itemId)
  if (cartItem) {
    if (cartItem.quantity > 1) {
      cartItem.quantity--
    } else {
      appState.cart = appState.cart.filter((c) => c.id !== itemId)
    }
    renderMenu(appState.menuItems.find((m) => m.id === itemId)?.category || "all")
  }
}

// ===================== CHECKOUT PAGE =====================
function renderCheckout() {
  // Render items
  const checkoutItems = document.getElementById("checkout-items")
  checkoutItems.innerHTML = ""
  let total = 0

  appState.cart.forEach((item) => {
    const itemTotal = item.price * item.quantity
    total += itemTotal
    checkoutItems.innerHTML += `
      <div class="checkout-item">
        <span class="checkout-item-name">${item.name} x${item.quantity}</span>
        <span class="checkout-item-price">Rp ${itemTotal.toLocaleString()}</span>
      </div>
    `
  })

  document.getElementById("checkout-total").textContent = `Rp ${total.toLocaleString()}`

  // Show/hide table selection based on delivery type
  updateTableVisibility()
}

function updateTableVisibility() {
  const deliveryType = document.querySelector('input[name="delivery"]:checked').value
  const tableSelection = document.getElementById("table-selection")

  if (deliveryType === "dine-in" && !appState.tableFromQR) {
    tableSelection.style.display = "block"
  } else if (appState.tableFromQR && deliveryType === "dine-in") {
    // Meja sudah dipilih dari QR, tampilkan sebagai read-only
    tableSelection.innerHTML = `
      <h3>Meja Anda</h3>
      <div style="background: var(--light-bg); padding: 12px; border-radius: 8px; text-align: center; font-weight: 600; color: var(--primary-dark-purple);">
        Meja ${appState.selectedTable} (dari QR Code)
      </div>
    `
    tableSelection.style.display = "block"
  } else {
    tableSelection.style.display = "none"
  }
}

function selectTable(tableNum) {
  appState.selectedTable = tableNum
  document.querySelectorAll(".table-btn-checkout").forEach((btn, index) => {
    btn.classList.toggle("selected", index + 1 === tableNum)
  })
}

function selectPayment(method) {
  appState.selectedPayment = method
  document.querySelectorAll(".payment-btn").forEach((btn) => {
    btn.classList.remove("selected")
  })
  event.target.closest(".payment-btn").classList.add("selected")

  // Show/hide phone input for e-wallet
  const phoneInput = document.getElementById("phone-input")
  if (method === "gopay" || method === "shopeepay") {
    phoneInput.style.display = "block"
  } else {
    phoneInput.style.display = "none"
  }
}

function processCheckout() {
  if (appState.cart.length === 0) {
    alert("Keranjang kosong!")
    return
  }

  const deliveryType = document.querySelector('input[name="delivery"]:checked').value

  if (deliveryType === "dine-in" && !appState.selectedTable && !appState.tableFromQR) {
    alert("Pilih meja terlebih dahulu!")
    return
  }

  if (!appState.selectedPayment) {
    alert("Pilih metode pembayaran!")
    return
  }

  // Create order
  const order = {
    id: "ORDER-" + Date.now(),
    items: [...appState.cart],
    table: appState.selectedTable,
    deliveryType: deliveryType,
    paymentMethod: appState.selectedPayment,
    status: "pending",
    createdAt: new Date().toLocaleString(),
    confirmationTime: null,
    preparedAt: null,
    readyAt: null,
    completedAt: null,
  }

  appState.orders.push(order)
  saveData()

  // Reset cart
  appState.cart = []
  appState.selectedTable = null
  appState.tableFromQR = false
  appState.selectedPayment = null

  // Go to order status page with order ID
  localStorage.setItem("currentOrderId", order.id)
  goToPage("order-status-page")
}

// ===================== QR SCAN PAGE =====================
function selectTableFromQR(tableNum) {
  appState.selectedTable = tableNum
  appState.tableFromQR = true
  goToPage("checkout-page")
}

// ===================== TRACKING PAGE =====================
function renderTracking() {
  const trackingList = document.getElementById("tracking-list")
  trackingList.innerHTML = ""

  // Filter out completed orders
  const activeOrders = appState.orders.filter((o) => o.status !== "completed")

  if (activeOrders.length === 0) {
    trackingList.innerHTML = '<p style="text-align: center; padding: 40px; color: #6b7280;">Tidak ada pesanan aktif</p>'
    return
  }

  activeOrders
    .slice()
    .reverse()
    .forEach((order) => {
      const statusClass = `tracking-status ${order.status}`
      const statusText = {
        pending: "Menunggu Konfirmasi",
        preparing: "Sedang Dibuat",
        ready: "Siap Diambil",
        completed: "Selesai",
      }[order.status]

      const html = `
      <div class="tracking-item" onclick="viewOrderStatus('${order.id}')">
        <div class="tracking-header">
          <span class="tracking-id">${order.id}</span>
          <span class="${statusClass}">${statusText}</span>
        </div>
        <div class="tracking-details">
          <div>Item: ${order.items.map((i) => i.name).join(", ")}</div>
          <div>Total: Rp ${order.items.reduce((sum, i) => sum + i.price * i.quantity, 0).toLocaleString()}</div>
          <div>Waktu: ${order.createdAt}</div>
        </div>
      </div>
    `
      trackingList.innerHTML += html
    })
}

function viewOrderStatus(orderId) {
  localStorage.setItem("currentOrderId", orderId)
  goToPage("order-status-page")
}

// ===================== ORDER STATUS PAGE =====================
function renderOrderStatus() {
  const orderId = localStorage.getItem("currentOrderId")
  const order = appState.orders.find((o) => o.id === orderId)

  if (!order) {
    document.getElementById("status-timeline").innerHTML = "<p>Pesanan tidak ditemukan</p>"
    return
  }

  const steps = [
    { title: "Pesanan Dikonfirmasi", status: "pending", time: order.createdAt },
    { title: "Sedang Dibuat", status: "preparing", time: order.confirmationTime || "-" },
    { title: "Siap Diambil", status: "ready", time: order.preparedAt || "-" },
    { title: "Selesai", status: "completed", time: order.completedAt || "-" },
  ]

  const timeline = document.getElementById("status-timeline")
  timeline.innerHTML = ""

  steps.forEach((step, index) => {
    const isCompleted =
      (step.status === "pending" && order.status !== "pending") ||
      (step.status === "preparing" &&
        (order.status === "preparing" || order.status === "ready" || order.status === "completed")) ||
      (step.status === "ready" && (order.status === "ready" || order.status === "completed")) ||
      (step.status === "completed" && order.status === "completed")

    const html = `
      <div class="status-step ${isCompleted ? "completed" : ""}">
        <div class="status-indicator">${isCompleted ? "✓" : index + 1}</div>
        <div class="status-content">
          <div class="status-title">${step.title}</div>
          <div class="status-time">${step.time}</div>
        </div>
      </div>
    `
    timeline.innerHTML += html
  })
}

// ===================== AUTHENTICATION =====================
function togglePasswordVisibility(inputId) {
  const input = document.getElementById(inputId)
  const btn = event.target

  if (input.type === "password") {
    input.type = "text"
    btn.textContent = "👁️‍🗨️"
  } else {
    input.type = "password"
    btn.textContent = "👁️"
  }
}

function vendorLogin() {
  const email = document.getElementById("login-email").value
  const password = document.getElementById("login-password").value

  const user = appState.users.find((u) => u.email === email && u.password === password)

  if (user) {
    appState.currentUser = user
    localStorage.setItem("currentUser", JSON.stringify(user))
    goToPage("vendor-dashboard-page")
  } else {
    alert("Email atau password salah!")
  }

  document.getElementById("login-email").value = ""
  document.getElementById("login-password").value = ""
}

function vendorRegister() {
  const email = document.getElementById("register-email").value
  const password = document.getElementById("register-password").value
  const confirmPassword = document.getElementById("register-confirm").value

  if (!email || !password || !confirmPassword) {
    alert("Semua field harus diisi!")
    return
  }

  if (password !== confirmPassword) {
    alert("Password tidak cocok!")
    return
  }

  if (appState.users.find((u) => u.email === email)) {
    alert("Email sudah terdaftar!")
    return
  }

  const newUser = {
    id: appState.users.length + 1,
    email: email,
    password: password,
  }

  appState.users.push(newUser)
  saveData()
  alert("Registrasi berhasil! Silakan login.")
  goToPage("vendor-login-page")

  document.getElementById("register-email").value = ""
  document.getElementById("register-password").value = ""
  document.getElementById("register-confirm").value = ""
}

function vendorLogout() {
  appState.currentUser = null
  localStorage.removeItem("currentUser")
  goToPage("home-page")
}

// ===================== VENDOR DASHBOARD =====================
function renderVendorDashboard() {
  const storedUser = localStorage.getItem("currentUser")
  if (!storedUser) {
    goToPage("vendor-login-page")
    return
  }

  appState.currentUser = JSON.parse(storedUser)
  switchVendorTab("orders")
}

function switchVendorTab(tabName) {
  // Hide all tabs
  document.querySelectorAll(".vendor-tab").forEach((tab) => {
    tab.classList.remove("active")
  })

  // Remove active from nav buttons
  document.querySelectorAll(".vendor-nav-btn").forEach((btn) => {
    btn.classList.remove("active")
  })

  // Show selected tab
  document.getElementById(`${tabName}-tab`).classList.add("active")
  event.target.classList.add("active")

  // Load tab content
  if (tabName === "orders") {
    filterOrders("pending")
  } else if (tabName === "menu") {
    renderMenuManagement()
  } else if (tabName === "tables") {
    renderTablesManagement()
  } else if (tabName === "financial") {
    renderFinancial()
  }
}

function filterOrders(status) {
  const ordersList = document.getElementById("orders-list")
  ordersList.innerHTML = ""

  const filteredOrders = appState.orders.filter((o) => o.status === status)

  // Update tab buttons
  document.querySelectorAll(".order-tab-btn").forEach((btn) => {
    btn.classList.remove("active")
  })
  event.target.classList.add("active")

  if (filteredOrders.length === 0) {
    ordersList.innerHTML = '<p style="text-align: center; padding: 40px;">Tidak ada pesanan</p>'
    return
  }

  filteredOrders.forEach((order) => {
    const html = `
      <div class="order-card">
        <div class="order-header">
          <span class="order-id">${order.id}</span>
          <span class="order-time">${order.createdAt}</span>
        </div>
        <div class="order-items">
          ${order.items.map((item) => `<div class="order-item">${item.name} x${item.quantity}</div>`).join("")}
        </div>
        <div class="order-actions">
          ${
            status === "pending"
              ? `
            <button class="order-action-btn primary" onclick="updateOrderStatus('${order.id}', 'preparing')">Buat</button>
            <button class="order-action-btn secondary" onclick="showCashConfirmation('${order.id}')">Konfirmasi</button>
          `
              : ""
          }
          ${
            status === "preparing"
              ? `
            <button class="order-action-btn primary" onclick="updateOrderStatus('${order.id}', 'ready')">Siap</button>
          `
              : ""
          }
          ${
            status === "ready"
              ? `
            <button class="order-action-btn primary" onclick="updateOrderStatus('${order.id}', 'completed')">Selesai</button>
          `
              : ""
          }
        </div>
      </div>
    `
    ordersList.innerHTML += html
  })
}

function showCashConfirmation(orderId) {
  const order = appState.orders.find((o) => o.id === orderId)
  if (order && order.paymentMethod === "cash") {
    alert(
      `Konfirmasi pembayaran tunai untuk ${order.id}?\nTotal: Rp ${order.items.reduce((sum, i) => sum + i.price * i.quantity, 0).toLocaleString()}`,
    )
  } else {
    alert("Pesanan ini bukan pembayaran tunai")
  }
}

function updateOrderStatus(orderId, newStatus) {
  const order = appState.orders.find((o) => o.id === orderId)
  if (order) {
    order.status = newStatus
    if (newStatus === "preparing") {
      order.confirmationTime = new Date().toLocaleString()
    } else if (newStatus === "ready") {
      order.preparedAt = new Date().toLocaleString()
    } else if (newStatus === "completed") {
      order.completedAt = new Date().toLocaleString()
    }
    saveData()
    filterOrders(newStatus)
  }
}

// ===================== MENU MANAGEMENT =====================
function renderMenuManagement() {
  const list = document.getElementById("menu-management-list")
  list.innerHTML = ""

  appState.menuItems.forEach((item) => {
    const html = `
      <div class="menu-edit-item">
        <div class="menu-edit-info">
          <div class="menu-edit-name">${item.name}</div>
          <div class="menu-edit-price">Rp ${item.price.toLocaleString()}</div>
        </div>
        <div class="menu-edit-actions">
          <button class="menu-edit-btn edit" onclick="editMenu(${item.id})">Edit</button>
          <button class="menu-edit-btn delete" onclick="deleteMenu(${item.id})">Hapus</button>
        </div>
      </div>
    `
    list.innerHTML += html
  })
}

function showAddMenuForm() {
  document.getElementById("menu-form").style.display = "block"
}

function hideAddMenuForm() {
  document.getElementById("menu-form").style.display = "none"
  document.getElementById("menu-name").value = ""
  document.getElementById("menu-price").value = ""
}

function saveMenu() {
  const name = document.getElementById("menu-name").value
  const price = Number.parseInt(document.getElementById("menu-price").value)
  const category = document.getElementById("menu-category").value

  if (!name || !price) {
    alert("Nama dan harga harus diisi!")
    return
  }

  const newItem = {
    id: Math.max(...appState.menuItems.map((m) => m.id), 0) + 1,
    name: name,
    price: price,
    category: category,
    image: "/placeholder.svg?height=180&width=180&query=" + name,
  }

  appState.menuItems.push(newItem)
  saveData()
  hideAddMenuForm()
  renderMenuManagement()
  alert("Menu berhasil ditambahkan!")
}

function deleteMenu(id) {
  if (confirm("Hapus menu ini?")) {
    appState.menuItems = appState.menuItems.filter((m) => m.id !== id)
    saveData()
    renderMenuManagement()
  }
}

function editMenu(id) {
  alert("Fitur edit akan datang")
}

// ===================== TABLES MANAGEMENT =====================
function renderTablesManagement() {
  // Tables ini hanya untuk demo, bisa ditambah lebih banyak
  const list = document.getElementById("tables-management-list")
  list.innerHTML = ""

  for (let i = 1; i <= 6; i++) {
    const html = `
      <div class="menu-edit-item">
        <div class="menu-edit-info">
          <div class="menu-edit-name">Meja ${i}</div>
          <div class="menu-edit-price">QR Code: table-${i}</div>
        </div>
        <div class="menu-edit-actions">
          <button class="menu-edit-btn edit" onclick="copyQRCode(${i})">Copy</button>
          <button class="menu-edit-btn delete" onclick="deleteTable(${i})">Hapus</button>
        </div>
      </div>
    `
    list.innerHTML += html
  }
}

function showAddTableForm() {
  document.getElementById("table-form").style.display = "block"
}

function hideAddTableForm() {
  document.getElementById("table-form").style.display = "none"
  document.getElementById("table-name").value = ""
}

function saveTable() {
  const name = document.getElementById("table-name").value
  if (!name) {
    alert("Nama meja harus diisi!")
    return
  }
  hideAddTableForm()
  renderTablesManagement()
  alert("Meja berhasil ditambahkan!")
}

function copyQRCode(tableNum) {
  const qrCode = `table-${tableNum}`
  navigator.clipboard.writeText(qrCode)
  alert("QR Code copied: " + qrCode)
}

function deleteTable(tableNum) {
  if (confirm(`Hapus Meja ${tableNum}?`)) {
    alert("Meja berhasil dihapus")
  }
}

// ===================== FINANCIAL PAGE =====================
function renderFinancial() {
  const stats = {
    totalRevenue: 0,
    totalOrders: 0,
    avgTransaction: 0,
  }

  appState.orders.forEach((order) => {
    const total = order.items.reduce((sum, i) => sum + i.price * i.quantity, 0)
    stats.totalRevenue += total
    stats.totalOrders++
  })

  stats.avgTransaction = stats.totalOrders > 0 ? Math.round(stats.totalRevenue / stats.totalOrders) : 0

  document.getElementById("total-revenue").textContent = `Rp ${stats.totalRevenue.toLocaleString()}`
  document.getElementById("total-orders").textContent = stats.totalOrders
  document.getElementById("avg-transaction").textContent = `Rp ${stats.avgTransaction.toLocaleString()}`

  // Render transaction table
  const tbody = document.getElementById("financial-tbody")
  tbody.innerHTML = ""

  appState.orders.forEach((order) => {
    const total = order.items.reduce((sum, i) => sum + i.price * i.quantity, 0)
    const items = order.items.map((i) => i.name).join(", ")

    const html = `
      <tr>
        <td>${order.createdAt}</td>
        <td>${items}</td>
        <td>${order.items.reduce((sum, i) => sum + i.quantity, 0)}</td>
        <td>${order.paymentMethod}</td>
        <td>Rp ${total.toLocaleString()}</td>
      </tr>
    `
    tbody.innerHTML += html
  })
}

// ===================== SETTINGS PAGE =====================
function updateEmail() {
  const newEmail = document.getElementById("new-email").value
  if (!newEmail) {
    alert("Email harus diisi!")
    return
  }
  appState.currentUser.email = newEmail
  // Update in users list
  const user = appState.users.find((u) => u.id === appState.currentUser.id)
  if (user) user.email = newEmail
  saveData()
  localStorage.setItem("currentUser", JSON.stringify(appState.currentUser))
  alert("Email berhasil diubah!")
  document.getElementById("new-email").value = ""
}

function updatePassword() {
  const newPassword = document.getElementById("new-password").value
  if (!newPassword) {
    alert("Password harus diisi!")
    return
  }
  appState.currentUser.password = newPassword
  // Update in users list
  const user = appState.users.find((u) => u.id === appState.currentUser.id)
  if (user) user.password = newPassword
  saveData()
  localStorage.setItem("currentUser", JSON.stringify(appState.currentUser))
  alert("Password berhasil diubah!")
  document.getElementById("new-password").value = ""
}

// ===================== EVENT LISTENERS =====================
function attachEventListeners() {
  // Delivery type change
  document.querySelectorAll('input[name="delivery"]').forEach((radio) => {
    radio.addEventListener("change", () => {
      appState.deliveryType = radio.value
      updateTableVisibility()
    })
  })
}

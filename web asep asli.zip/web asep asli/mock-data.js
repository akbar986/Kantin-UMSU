// ===================== MOCK DATA =====================
// This file contains all static data for the canteen ordering system

const mockMenuItems = [
  {
    id: 1,
    name: "Nasi Goreng",
    price: 15000,
    category: "makanan",
    image: "/indonesian-fried-rice.jpg",
    available: true,
  },
  {
    id: 2,
    name: "Mie Goreng",
    price: 12000,
    category: "makanan",
    image: "/indonesian-fried-noodles.jpg",
    available: true,
  },
  {
    id: 3,
    name: "Ayam Geprek",
    price: 18000,
    category: "makanan",
    image: "/smashed-fried-chicken.jpg",
    available: true,
  },
  {
    id: 4,
    name: "Ayam Penyet",
    price: 17000,
    category: "makanan",
    image: "/pressed-fried-chicken.jpg",
    available: true,
  },
  {
    id: 5,
    name: "Soto Ayam",
    price: 13000,
    category: "makanan",
    image: "/indonesian-chicken-soup.jpg",
    available: true,
  },
  {
    id: 6,
    name: "Bakso",
    price: 12000,
    category: "makanan",
    image: "/indonesian-meatball-soup.jpg",
    available: true,
  },
  {
    id: 7,
    name: "Es Teh",
    price: 3000,
    category: "minuman",
    image: "/iced-tea.png",
    available: true,
  },
  {
    id: 8,
    name: "Es Jeruk",
    price: 5000,
    category: "minuman",
    image: "/glass-of-orange-juice.png",
    available: true,
  },
  {
    id: 9,
    name: "Cappuccino",
    price: 8000,
    category: "minuman",
    image: "/cappuccino-coffee.png",
    available: true,
  },
  {
    id: 10,
    name: "Mineral Water",
    price: 3000,
    category: "minuman",
    image: "/mineral-water-bottle.jpg",
    available: true,
  },
]

// Default admin user
const defaultUsers = [
  {
    id: 1,
    email: "admin@kantin.com",
    password: "admin123",
    name: "Administrator",
  },
]

// Table information
const tableInfo = [
  { number: "1", qrCode: "table-1", createdAt: new Date() },
  { number: "2", qrCode: "table-2", createdAt: new Date() },
  { number: "3", qrCode: "table-3", createdAt: new Date() },
  { number: "4", qrCode: "table-4", createdAt: new Date() },
  { number: "5", qrCode: "table-5", createdAt: new Date() },
  { number: "6", qrCode: "table-6", createdAt: new Date() },
]

// Payment methods
const paymentMethods = [
  { id: "qris", name: "QRIS", icon: "📲", type: "instant" },
  { id: "gopay", name: "GoPay", icon: "🟢", type: "ewallet" },
  { id: "shopeepay", name: "ShopeePay", icon: "🔴", type: "ewallet" },
  { id: "cash", name: "Tunai", icon: "💵", type: "cash" },
]

// Order status labels
const orderStatusLabels = {
  pending: "Menunggu Konfirmasi",
  preparing: "Sedang Dibuat",
  ready: "Siap Diambil",
  completed: "Selesai",
}

// Order status colors (for styling)
const orderStatusColors = {
  pending: { bg: "#fef3c7", color: "#92400e" },
  preparing: { bg: "#bfdbfe", color: "#1e40af" },
  ready: { bg: "#bbf7d0", color: "#065f46" },
  completed: { bg: "#d1d5db", color: "#374151" },
}

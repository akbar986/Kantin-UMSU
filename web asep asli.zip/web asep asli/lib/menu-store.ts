"use client"

import type { MenuItem } from "./types"
import { menuItems as defaultMenuItems } from "./mock-data"

export function getMenuItems(): MenuItem[] {
  if (typeof window !== "undefined") {
    const customItems = localStorage.getItem("customMenuItems")
    if (customItems) {
      return JSON.parse(customItems)
    }
  }
  return defaultMenuItems
}

export function saveMenuItems(items: MenuItem[]): void {
  if (typeof window !== "undefined") {
    localStorage.setItem("customMenuItems", JSON.stringify(items))
  }
}

export function addMenuItem(item: MenuItem): void {
  const items = getMenuItems()
  items.push(item)
  saveMenuItems(items)
}

export function updateMenuItem(id: string, updates: Partial<MenuItem>): void {
  const items = getMenuItems()
  const index = items.findIndex((i) => i.id === id)
  if (index !== -1) {
    items[index] = { ...items[index], ...updates }
    saveMenuItems(items)
  }
}

export function deleteMenuItem(id: string): void {
  const items = getMenuItems()
  const filtered = items.filter((i) => i.id !== id)
  saveMenuItems(filtered)
}

export function generateMenuItemId(): string {
  return `MENU-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
}

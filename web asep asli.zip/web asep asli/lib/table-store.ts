"use client"

import type { TableInfo } from "./types"

export function getTables(): TableInfo[] {
  if (typeof window !== "undefined") {
    const tables = localStorage.getItem("tables")
    if (tables) {
      return JSON.parse(tables)
    }
  }
  return getDefaultTables()
}

function getDefaultTables(): TableInfo[] {
  return Array.from({ length: 10 }, (_, i) => ({
    number: `${i + 1}`,
    qrCode: `${process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000"}/scan?table=${i + 1}`,
    createdAt: new Date(),
  }))
}

export function saveTables(tables: TableInfo[]): void {
  if (typeof window !== "undefined") {
    localStorage.setItem("tables", JSON.stringify(tables))
  }
}

export function addTable(tableNumber: string): void {
  const tables = getTables()
  if (!tables.find((t) => t.number === tableNumber)) {
    tables.push({
      number: tableNumber,
      qrCode: `${process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000"}/scan?table=${tableNumber}`,
      createdAt: new Date(),
    })
    saveTables(tables)
  }
}

export function deleteTable(tableNumber: string): void {
  const tables = getTables()
  const filtered = tables.filter((t) => t.number !== tableNumber)
  saveTables(filtered)
}

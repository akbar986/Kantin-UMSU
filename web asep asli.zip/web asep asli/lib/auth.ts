"use client"

// Extended authentication system to support multiple vendors with registration
type VendorAccount = {
  email: string
  password: string
  name: string
  createdAt: string
}

const vendorAccounts: Record<string, VendorAccount> = {
  "penjual@kantin.com": {
    email: "penjual@kantin.com",
    password: "penjual123",
    name: "Kantin UMSU",
    createdAt: new Date().toISOString(),
  },
}

export function registerVendor(email: string, password: string, name: string): { success: boolean; error?: string } {
  if (vendorAccounts[email]) {
    return { success: false, error: "Email sudah terdaftar" }
  }

  if (password.length < 6) {
    return { success: false, error: "Password minimal 6 karakter" }
  }

  vendorAccounts[email] = {
    email,
    password,
    name,
    createdAt: new Date().toISOString(),
  }

  if (typeof window !== "undefined") {
    localStorage.setItem("vendorAccounts", JSON.stringify(vendorAccounts))
  }

  return { success: true }
}

export function loginVendor(email: string, password: string): boolean {
  const account = vendorAccounts[email]

  if (account && account.password === password) {
    if (typeof window !== "undefined") {
      localStorage.setItem(
        "vendorAuth",
        JSON.stringify({
          email: account.email,
          name: account.name,
          loggedInAt: new Date().toISOString(),
        }),
      )
    }
    return true
  }
  return false
}

export function logoutVendor(): void {
  if (typeof window !== "undefined") {
    localStorage.removeItem("vendorAuth")
  }
}

export function isVendorAuthenticated(): boolean {
  if (typeof window !== "undefined") {
    const auth = localStorage.getItem("vendorAuth")
    return auth !== null
  }
  return false
}

export function getVendorInfo() {
  if (typeof window !== "undefined") {
    const auth = localStorage.getItem("vendorAuth")
    if (auth) {
      return JSON.parse(auth)
    }
  }
  return null
}

export function changePassword(oldPassword: string, newPassword: string): { success: boolean; error?: string } {
  const vendorInfo = getVendorInfo()
  if (!vendorInfo) {
    return { success: false, error: "Vendor tidak login" }
  }

  const account = vendorAccounts[vendorInfo.email]
  if (!account || account.password !== oldPassword) {
    return { success: false, error: "Password lama tidak sesuai" }
  }

  if (newPassword.length < 6) {
    return { success: false, error: "Password minimal 6 karakter" }
  }

  account.password = newPassword
  if (typeof window !== "undefined") {
    localStorage.setItem("vendorAccounts", JSON.stringify(vendorAccounts))
  }

  return { success: true }
}

export function changeEmail(newEmail: string, password: string): { success: boolean; error?: string } {
  const vendorInfo = getVendorInfo()
  if (!vendorInfo) {
    return { success: false, error: "Vendor tidak login" }
  }

  const account = vendorAccounts[vendorInfo.email]
  if (!account || account.password !== password) {
    return { success: false, error: "Password tidak sesuai" }
  }

  if (vendorAccounts[newEmail]) {
    return { success: false, error: "Email sudah terdaftar" }
  }

  vendorAccounts[newEmail] = { ...account, email: newEmail }
  delete vendorAccounts[vendorInfo.email]

  if (typeof window !== "undefined") {
    localStorage.setItem("vendorAccounts", JSON.stringify(vendorAccounts))
    localStorage.setItem(
      "vendorAuth",
      JSON.stringify({
        email: newEmail,
        name: account.name,
        loggedInAt: new Date().toISOString(),
      }),
    )
  }

  return { success: true }
}

export function getCurrentPassword(): string {
  const vendorInfo = getVendorInfo()
  if (vendorInfo && vendorAccounts[vendorInfo.email]) {
    return vendorAccounts[vendorInfo.email].password
  }
  return ""
}

export function getCurrentEmail(): string {
  const vendorInfo = getVendorInfo()
  if (vendorInfo) {
    return vendorInfo.email
  }
  return ""
}

"use client"

import type { Order } from "./types"

// Simple order management using localStorage
export function saveOrder(order: Order): void {
  if (typeof window !== "undefined") {
    const orders = getOrders()
    orders.push(order)
    localStorage.setItem("orders", JSON.stringify(orders))
  }
}

export function getOrders(): Order[] {
  if (typeof window !== "undefined") {
    const ordersJson = localStorage.getItem("orders")
    if (ordersJson) {
      const orders = JSON.parse(ordersJson)
      return orders.map((order: any) => ({
        ...order,
        createdAt: new Date(order.createdAt),
        updatedAt: new Date(order.updatedAt),
      }))
    }
  }
  return []
}

export function updateOrderStatus(orderId: string, status: Order["status"]): void {
  if (typeof window !== "undefined") {
    const orders = getOrders()
    const orderIndex = orders.findIndex((o) => o.id === orderId)
    if (orderIndex !== -1) {
      orders[orderIndex].status = status
      orders[orderIndex].updatedAt = new Date()
      localStorage.setItem("orders", JSON.stringify(orders))
    }
  }
}

export function getOrderById(orderId: string): Order | null {
  const orders = getOrders()
  return orders.find((o) => o.id === orderId) || null
}

export function generateOrderId(): string {
  return `ORD-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
}

export function updateOrderPayment(orderId: string, phoneNumber: string, confirmed: boolean): void {
  if (typeof window !== "undefined") {
    const orders = getOrders()
    const orderIndex = orders.findIndex((o) => o.id === orderId)
    if (orderIndex !== -1) {
      orders[orderIndex].phoneNumber = phoneNumber
      orders[orderIndex].paymentConfirmed = confirmed
      if (confirmed) {
        orders[orderIndex].paymentTime = new Date()
      }
      orders[orderIndex].updatedAt = new Date()
      localStorage.setItem("orders", JSON.stringify(orders))
    }
  }
}

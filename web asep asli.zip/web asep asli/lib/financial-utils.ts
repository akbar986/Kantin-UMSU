import type { Order } from "./types"

export interface DailyReport {
  date: string
  totalOrders: number
  completedOrders: number
  totalRevenue: number
  averageOrderValue: number
}

export interface PaymentMethodStats {
  method: string
  count: number
  total: number
  percentage: number
}

export interface ItemSalesStats {
  name: string
  quantity: number
  revenue: number
}

export function generateDailyReport(orders: Order[]): DailyReport[] {
  const dailyData = orders.reduce(
    (acc, order) => {
      const date = new Date(order.createdAt).toLocaleDateString("id-ID")
      if (!acc[date]) {
        acc[date] = {
          totalOrders: 0,
          completedOrders: 0,
          totalRevenue: 0,
        }
      }
      acc[date].totalOrders++
      if (order.status === "completed") {
        acc[date].completedOrders++
      }
      acc[date].totalRevenue += order.total
      return acc
    },
    {} as Record<string, { totalOrders: number; completedOrders: number; totalRevenue: number }>,
  )

  return Object.entries(dailyData).map(([date, data]) => ({
    date,
    ...data,
    averageOrderValue: data.totalOrders > 0 ? data.totalRevenue / data.totalOrders : 0,
  }))
}

export function calculatePaymentMethodStats(orders: Order[]): PaymentMethodStats[] {
  const totalOrders = orders.length

  const methodStats = orders.reduce(
    (acc, order) => {
      if (!acc[order.paymentMethod]) {
        acc[order.paymentMethod] = { count: 0, total: 0 }
      }
      acc[order.paymentMethod].count++
      acc[order.paymentMethod].total += order.total
      return acc
    },
    {} as Record<string, { count: number; total: number }>,
  )

  return Object.entries(methodStats).map(([method, stats]) => ({
    method,
    count: stats.count,
    total: stats.total,
    percentage: totalOrders > 0 ? (stats.count / totalOrders) * 100 : 0,
  }))
}

export function getTopSellingItems(orders: Order[], limit = 10): ItemSalesStats[] {
  const itemSales = orders.reduce(
    (acc, order) => {
      order.items.forEach((item) => {
        if (!acc[item.name]) {
          acc[item.name] = { quantity: 0, revenue: 0 }
        }
        acc[item.name].quantity += item.quantity
        acc[item.name].revenue += item.price * item.quantity
      })
      return acc
    },
    {} as Record<string, { quantity: number; revenue: number }>,
  )

  return Object.entries(itemSales)
    .map(([name, stats]) => ({
      name,
      ...stats,
    }))
    .sort((a, b) => b.revenue - a.revenue)
    .slice(0, limit)
}

export function calculateRevenueTrend(orders: Order[], days = 7): number {
  const now = new Date()
  const periodStart = new Date(now.getTime() - days * 24 * 60 * 60 * 1000)

  const currentPeriod = orders.filter((o) => new Date(o.createdAt) >= periodStart)
  const previousPeriod = orders.filter((o) => {
    const date = new Date(o.createdAt)
    return date < periodStart && date >= new Date(periodStart.getTime() - days * 24 * 60 * 60 * 1000)
  })

  const currentRevenue = currentPeriod.reduce((sum, o) => sum + o.total, 0)
  const previousRevenue = previousPeriod.reduce((sum, o) => sum + o.total, 0)

  if (previousRevenue === 0) return currentRevenue > 0 ? 100 : 0

  return ((currentRevenue - previousRevenue) / previousRevenue) * 100
}

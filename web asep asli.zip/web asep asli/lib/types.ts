// Type definitions for the canteen ordering system

export interface MenuItem {
  id: string
  name: string
  price: number
  category: "food" | "drink"
  image: string
  available: boolean
}

export interface CartItem extends MenuItem {
  quantity: number
}

export interface Order {
  id: string
  tableNumber: string
  items: CartItem[]
  total: number
  status: "pending" | "confirmed" | "preparing" | "ready" | "completed"
  paymentMethod: "cash" | "gopay" | "shopee" | "qris"
  phoneNumber?: string // For e-wallet confirmation
  paymentConfirmed: boolean
  paymentTime?: Date
  createdAt: Date
  updatedAt: Date
  source?: "qr" | "menu" // Track if order came from QR scan or menu browse
  isDelivery?: boolean // Added delivery/takeaway option
}

export interface Vendor {
  id: string
  email: string
  name: string
  password: string
}

export interface VendorSettings {
  tables: TableInfo[]
  menus: MenuItem[]
}

export interface TableInfo {
  number: string
  qrCode: string
  createdAt: Date
}

export interface FinancialReport {
  date: string
  totalOrders: number
  totalRevenue: number
  orders: Order[]
}
